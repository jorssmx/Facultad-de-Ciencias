Práctica 2

Nombre: Jorge Angel Sánchez Sánchez
No Cuenta: 315155534

Fui resolviendo la práctica mediante las instrucciones y en orden a como se acomo cada actividad.
Despues de crear mi clase Mascota primero realice la actividad 1 que consistia en poner los atributos correspondientes
ya sea publico,privado o estatico que en mi caso fue publico y estatico.
Posteriormente pase por la actividad 2 de implementar todos los getters y setters de los atributos creados.
Luego pase a la actividad 3 y aqui empezaban las complicaciones ya que no sabia como realizar el problema y luego de una seccion de laboratorio
me quite las dudas que tenia y empece a realizar esta parte utilizando los metodos ya realizados y creando el main para que imprimiera en la 
terminal los datos de la mascota.
la actividad cuatro solo era crear una variable estatica que en mi caso le puse instancias que se referia a cuantas mascotas creé y en esa
variable cada que creabas una nueva mascota se aumentaba esa variable instancias que por cierto la pregunta de 

¿todas las mascotas tienen el mismo valor de dicha variable o es distinto para cada mascota?
y mi respuesta es: que es distinto el valor de la variable ya que si creas una mascota aumenta 1 unidad y por lo tanto modifica el valor 
de la varaible.

y por último la actividad 5 en esta fue en la que más me tarde ya que tenia varias dudas por ejemplo el ¿como utilizar los métodos de la otra clase
es decir si estamos en la clase "Veterinario" como utilizar los métodos de la clase "Mascota" ya que no hemos visto herencia y lo de package no 
lo se utilizar muy bien por lo que opte por enviarte un correo y me contestaste resolviendo mis dudas que tenía por lo que proceguí a hacerla por lo
que me complique la vida y la estaba haciendo muy dificil pero al final entendí bien lo del veterinario y pude resolverlo.

Las clases se compilan:

javac Mascota.java
javac Veterinario.java

y se prueban:

java Mascota
java Veterinario

