Práctica 3

Nombre: Jorge Angel Sánchez Sánchez
No Cuenta: 315155534

Fui resolviendo la práctica primero creando la clase y luego quería hacer método por método pero me salia error así que te envié correo del por que del error y supe que era por que tenia que implementar todos los métodos de la interfaz por lo que me diste un buen consejo y me diste un ejemplo lo hice y proseguí con mi programa, me atoré en el primer método "encuentraPosicion" ya que leí la nota importante y reglas importantes y me costo hacer ese método pues me limitabas con solo utilizar algunos métodos de String lo cual si me costo hacerlo por que no me salia y no me salia pero por fin salio a la vez esta bien limitar usar esos ya que había una manera super facil usando otros tipos de métodos aunque al final ese método no resulto ser tan dificil pero el pensarlo si me costo pero al ver que me quedo senti gran sastifaccion.Luego proseguí con el que se me hizo el más facil que es "sonIguales" ese si me salio rápido ah antes de eso hice el main para ir porbando los métodos lo hice con un switch ya que quiero hacer el punto extra y así fui resolviendo la practica método por método el esNumero me costo igual hacerlo ya que no se me ocurria una forma hasta que se me ocurrio hacer un "for" donde me diera las letras del "abecedario" y este se compare con la cadena y así si me salió el método. Ah! por cierto los métodos que ya había hecho los había realizado sin contar los espacios y me dí cuenta de esto cuando llegue a la parte de "polimorfismo", "reemplazaCaracter", "daSubcadena" y la de "contiene" pues este es muy necesario para realizar estos métodos por lo que tuve que hacer un método privado que quitara los espacios de una cacena y así poder realizar estos métodos y modificar los que ya había hecho. Primero hice el de "contiene", luego pase por el de "daSubcadena" y por último concluí con el de "reemplazarCaracter" y así al fin termine la práctica.

La Clase se compila:

javac Practica3.java

y para correrlo:

java Practica3      
