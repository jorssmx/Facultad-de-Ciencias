Nombre: Jorge Angel Sanchez Sanchez
No Cuenta: 315155534

primero empecé a hacer el de fibonacci ya que recorde que vimos en las clases este método y quise intentar este primero, luego pase a hacer el de
'palindromo' ya que utilizando un metodo privado recursivo pude hacer este método, posteriormente a hcaer el de cuentaCaracter ya que con me iba a
dar idea para hacer el de reemplazar caracter y pues si tuve algunos inconvenientes como por ejemplo se ciclaba y no llegaba a casos base y cosas 
así pero pude hacerlo y el de pascal con la ayuda que diste en clase casi salía y me desesperé y ya mejor lo entrego así.

Compila: 
javac *.java

Correr:
java Recursion
