Nombre: Jorge Angel Sanchez Sanchez
No Cuenta: 315155534

al principio intente intente el del espejo y no me quedaba luego pase a hacer el del gato ya que hice la tarea de "Adriana" y pues me puse a hacer ese
entonces tuve problemas con los dos primeros comprobaciones pues era algo que no contemple en la tarea y después lo intente con los métodos que 
habia hecho pero no salió así que opte por hacerlo literal por las posiciones y ya en el de colapsa y mas repetido me ayudo la ayudantia de laboratorio
que diste ya que me saco muchas dudas que tenía y con el ejemplo o tip que diste lo pude hacer pues como dijiste esos dos métodos eran muy parecidos
el de pascal me ayude con el que hiciste del ejemplo de piramide y creo que esos son con los que tuve más complicaciones. 
Ah! también tuve que implementar tres métodos para imprimir el de "espejo", "separaNumeros", "pascal" y "colapsa".

Compila: 
javac Arreglos.java

Correr:
java Arreglos
