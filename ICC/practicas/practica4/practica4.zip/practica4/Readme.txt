Nombre: Jorge Angel Sanchez Sanchez
No Cuenta: 315155534

Compila: 
javac ListaLigada.java

Correr:
java ListaLigada

Traté de hacer el de "ListaOrdena" pero no me quedo :c
