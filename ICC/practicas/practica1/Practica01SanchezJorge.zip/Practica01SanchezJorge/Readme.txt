la práctica la resolví siguiendo los pasos del pdf.
la actividad 3 los tipos de variables las defini respecto a su máximo de bites y
el tipo de número por ejemplo el float y el double ya que tienen punto decimal
los elegí respecto a la longitud del número ya que float tiene un máximo de 32 bytes y long es de 64 bytes por lo que el long acepta un número más grande. y así con los otros tipos.En donde podía poner el mismo tipo sería en los números treintaYDosMil y DosMilMillones ya que el tipo int y el tipo short tienen la misma capacidad de bytes que son 16, en true pues booleano, en char pues es solo un caracter y en el cientoVeintisiete es el máximo del tipo byte asi que justo quedaba ese tipo por eso lo puse.
En la actividad 4 la probe de diferentes formas primero de manera más directa pero me salian resultados diferentes también con Int al igual salian resultados
diferentes y ya la definitiva con double y separando cada cierto conjunto de
operaciones a una variable que los represente y así salia el resultado que 
comprobe.

para compilar hay que poner: javac Practica1.java

y para correrla hay que poner: java Practica1
