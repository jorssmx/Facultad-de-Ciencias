import java.lang.Math;
/**
 * Clase que implementa los metodos de una Interfaz
 * que es ServiciosComplejo
 * @author Jorge Angel Sanchez Sanchez
 * @version 1a
 * No Cuenta: 315155534
*/
public class Complejo implements ServiciosComplejo{
  //variables que representan numero real y numero imaginario
  private double numeroReal;
  private double numeroImaginario;
  //variables donde guardaremos calculos entre las otras variables
  double guardaR;
  double guardaI;

  /**
   * Metodo para obtener el numero real
   * @return double - el numero real
  */
  public double getNumeroReal(){
    return this.numeroReal;
  }

  /**
   * Metodo para asignar el numero real
   * @param numeroReal - el numero real
  */
  public void setNumeroReal(double numeroReal){
    this.numeroReal = numeroReal;
  }

  /**
   * Metodo para obtener el numero imaginario
   * @return double - el numero imaginario
  */
  public double getNumeroImaginario(){
    return this.numeroImaginario;
  }

  /**
   * Metodo para asignar el numero imaginario
   * @param numeroImaginario - el numero imaginario
   */
  public void setNumeroImaginario(double numeroImaginario){
    this.numeroImaginario = numeroImaginario;
  }

  /**
   * Metodo por Omision
   */
  public Complejo(){}

  /**
   * Metodo Constructor que recibe los datos del complejo
   * @param numeroReal - el numero numeroReal
   * @param numeroImaginario - el numero imaginario
  */
  public Complejo(double numeroReal, double numeroImaginario){
    this.numeroReal = numeroReal;
    this.numeroImaginario = numeroImaginario;
  }

  @Override
  public Complejo suma(Complejo otro){
    guardaR = numeroReal + otro.getNumeroReal();
    guardaI = getNumeroImaginario() + otro.getNumeroImaginario();

    Complejo c = new Complejo();
    c.setNumeroReal(guardaR);
    c.setNumeroImaginario(guardaI);
    return c;
  }

  @Override
  public Complejo multiplica(Complejo otro){
    guardaR = (otro.getNumeroReal() * numeroReal) - (otro.getNumeroImaginario() * numeroImaginario);
    guardaI = (otro.getNumeroImaginario() * numeroReal) + (otro.getNumeroReal() * numeroImaginario);

    Complejo c = new Complejo();
    c.setNumeroReal(guardaR);
    c.setNumeroImaginario(guardaI);
    return c;
  }

  @Override
  public Complejo cuadrado(){
    return multiplica(this);
  }

  @Override
  public Complejo cubo(){
    return multiplica(cuadrado());
  }

  @Override
  public Complejo conjugado(){
    guardaR = numeroReal;
    guardaI = numeroImaginario * -1;

    Complejo c = new Complejo();
    c.setNumeroReal(guardaR);
    c.setNumeroImaginario(guardaI);
    return c;
  }

  @Override
  public Complejo inverso(){
    double resultado = ((numeroReal * numeroReal) + (numeroImaginario * numeroImaginario));
    guardaR = numeroReal / resultado;
    guardaI = (numeroImaginario * -1 / resultado);

    Complejo c = new Complejo();
    c.setNumeroReal(guardaR);
    c.setNumeroImaginario(guardaI);

    return c;
  }

  @Override
  public Complejo divide(Complejo otro){

    guardaR = ((otro.getNumeroReal() * this.numeroReal + otro.getNumeroImaginario() * this.numeroImaginario))
              / (otro.getNumeroReal() * otro.getNumeroReal() + otro.getNumeroImaginario() * otro.getNumeroImaginario());
    guardaI = (this.numeroImaginario * otro.getNumeroReal() - this.numeroReal * otro.getNumeroImaginario())
              / (otro.getNumeroReal() * otro.getNumeroReal() + otro.getNumeroImaginario() * otro.getNumeroImaginario());

    Complejo c = new Complejo();
    c.setNumeroReal(guardaR);
    c.setNumeroImaginario(guardaI);
    return c;
  }

  @Override
  public double modulo(){
    double residuo = Math.sqrt((numeroReal * numeroReal) + (numeroImaginario * numeroImaginario));
    return residuo;
  }

  @Override
  public boolean esIgual(Complejo otro){
    boolean corresponde = numeroReal == otro.getNumeroReal() && numeroImaginario == otro.getNumeroImaginario();
    return corresponde;
  }

  @Override
  public String muestra(){
    return String.format("(%.1f, %.1fi)", numeroReal, numeroImaginario);
  }

  //main
  public static void main(String[] args) {
    //modificando x and y podemos observar todos los calculos
    Complejo x = new Complejo(1.0, 5.0);
    Complejo y = new Complejo(5.0, -9.0);
    Complejo z = new Complejo();

    System.out.println("-------------------------------------");
    System.out.println("Primer número complejo: "+ x.muestra());
    System.out.println("Segundo número complejo: "+ y.muestra());
    System.out.println("-------------------------------------");
    z = x.suma(y);
    System.out.println("La suma es: "+ z.muestra());
    System.out.println("--------------------------");
    z = x.multiplica(y);
    System.out.println("La multiplicacion es: "+ z.muestra());
    System.out.println("-------------------------------------");
    z = x.cuadrado();
    System.out.println("El cuadrado es: "+ z.muestra());
    System.out.println("-------------------------------");
    z = x.cubo();
    System.out.println("El cubo es: "+ z.muestra());
    System.out.println("----------------------------");
    z = x.conjugado();
    System.out.println("El conjugado es: "+ z.muestra());
    System.out.println("--------------------------------");
    z = x.inverso();
    System.out.println("El inverso es: "+ z.muestra());
    System.out.println("-------------------------------");
    z = x.divide(y);
    System.out.println("La divición es: "+ z.muestra());
    System.out.println("--------------------------------");
    System.out.println("El modulo es: "+ x.modulo());
    System.out.println("--------------------------------");
    System.out.println("True si son iguales y False si no lo son: "+ x.esIgual(y));
    System.out.println("----------------------------------------------------");
  }

}
