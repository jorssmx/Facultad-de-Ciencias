Jorge Angel Sanchez Sanchez
No Cuenta: 315155534

**************

Para Compilar:

javac *.java

**************

Para correrlo:

java Fabricas

***************************

En la carpeta también encontramos 4 documentos de texto con la extención txt.

- "catalogo1.txt" --> Este nos muestra los animales con los que podemos construir los alebrijes.

- "catalogo2.txt" --> Este nos muestra los animales con los que podemos construir los alebrijes.

- "archivoAlebrije1.txt" --> Este nos muestra un alebrije ya construido de la Fabrica 1 y al cual le haremos modificaciones.

- "archivoAlebrije2.txt" --> Este nos muestra un alebrije ya construido de la Fabrica 2 y al cual le haremos modificaciones.


