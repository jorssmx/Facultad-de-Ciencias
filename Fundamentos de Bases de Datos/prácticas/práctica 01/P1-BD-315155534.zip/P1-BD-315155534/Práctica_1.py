# Paqueterias Importadas.
from cgi import print_form
from http.client import SWITCHING_PROTOCOLS
from warnings import catch_warnings
import pandas as pd
import csv
from dataclasses import field
from fileinput import filename
from pandas import DataFrame

"""
Clase en el cuál hacemos lo que nos pide la práctica 01 de la materia de Bases de Datos utilizando la paqueteria csv y pandas.
@Author Jorge Angel Sánchez Sánchez
@Version 1a - Fecha de entrega 05/09/2022.
"""

"""
Método con el cuál obtenemos todos los datos de nuestro archivo scv en este caso del 'Inventario'.
@param filename - el archivo csv. 
@return el contenido del archivo csv. 
"""
def get_all_data(filename):
    filename = pd.read_csv("Inventario.csv", index_col="ID")
    return filename

"""
Método con el cuál obtenemos todos los datos de nuestro archivo scv en este caso el de 'Ventas'.
@param filename - el archivo csv. 
@return el contenido del archivo csv. 
"""
def get_all_data2(filename2):
    filename2 = pd.read_csv("Ventas.csv")
    return filename2

"""
Método para elegir alguna categoria de nuestro csv.
@param entrada - el valor a evaluar.
@return el dato obtenido. 
"""
def menu_categorias(entrada):
    if entrada == 1:
        return "Antibioticos"
    elif entrada == 2:
        return "Desinflamantes"
    elif entrada == 3:
        return "Analgesicos"
    elif entrada == 4:
        return "Alimentos"
    elif entrada == 5:
        return "Bebidas"
    elif entrada == 6:
        return "Otros"
    else: 
        print("\tEntrada invalida\t\n"+
              "\tvuelve intentarlo")
        return 

"""
Método para agregar un nuevo producto que no haya en nuestro archivo csv.
Es decir agregamos el id, nombre, categoria, precio y cantidad del producto.
Si existe el nombre del producto nos indica que el 'Producto es repetido'
"""
def nuevo_dato_Unico():
    df = pd.read_csv("Inventario.csv")
    Nombre = input("Ingresa el nombre del medicamento: ")
    try: 
        Categoria = int(input("-------------------"
                              "Elige la categoria:\n"+
                              "-------------------\n"+
                              "1: Antibioticos\n"+
                              "2: Desinflamantes\n"+
                              "3: Analgésicos\n"+
                              "4: Alimentos\n"+
                              "5: Bebidas\n"+
                              "6: Otros\n"))
    except ValueError:
        print("\t----------------------------------\n"+
              "\tLo siento pero eso no es un número\n"+
              "\t----------------------------------")
    #usa_switch(Categoria)
    menu_categorias(Categoria)
    try:
        Precio = int(input("Ingresa el precio del medicamento: "))
        Cantidad_de_Inventario = int(input("Ingresa la cantidad de " + Nombre + " en existencia: "))
        if (not(dato_unicos_array(Nombre,1) )):
            nuevo_registro = {'ID' : ultimo_Id() + 1, 'Nombre' : Nombre, 'Categoria' : menu_categorias(Categoria), 'Precio': Precio,'Cantidad_de_Inventario':Cantidad_de_Inventario}
            print(nuevo_registro)
            dato = pd.DataFrame(nuevo_registro, index={5})
            df = pd.concat([df, dato])
            df.to_csv('Inventario.csv',index=False,header=True)
            print("----------------------------------\n"+
                  "Ahora el contenido del csv es así:\n"+
                  "----------------------------------\n")
            print(get_all_data(filename))
        else: 
            print("Producto repetido") 
    except ValueError:
        print("\t----------------------------------\n"+
              "\tLo siento pero eso no es un número\n"+
              "\t----------------------------------")

def consultar_Dato():
    try: 
        consultar = int(input("----------------------------\n"+
                              "Elige que quieres consultar:\n"+
                              "----------------------------\n"+
                              "1: Id's\n"+
                              "2: Productos\n"+
                              "3: Categorias\n"+
                              "4: Precios\n"+
                              "5: Cantidad de inventario\n"+
                              "6: Categoria y Precio\n"+
                              "7: Categoria y Cantidad de Inventario\n"))
    except ValueError:
        print("\t----------------------------------\n"+
              "\tLo siento pero eso no es un número\n"+
              "\t----------------------------------")
    menu_consultar(consultar)

"""
Método con el cuál obtenemos el último ID de nuestro archivo csv.
"""
def ultimo_Id():
    df = pd.read_csv("Inventario.csv")
    return df.at[df.index[-1], "ID"]


"""
Método que nos dice si un dato existe en la columna de los valores unicos.
@param dato - el dato a evaluar.
@param el indice de la columna. 
@return Boolean - True si existe, False en otro caso. 
"""
def dato_unicos_array(dato,i):
    df = pd.read_csv("Inventario.csv")
    unicosColumna = df.iloc[:, i].unique()
    return dato in unicosColumna

"""
Método para elegir lo que quiere consultar de nuestro csv.
@param entrada - el valor a evaluar.
@return el dato obtenido. 
"""
def menu_consultar(entrada):
    if entrada == 1:
        return dato_unico_id()
    elif entrada == 2:
        return dato_unico_nombre()
    elif entrada == 3:
        return dato_unico_categoria()
    elif entrada == 4:
        return dato_unico_precio()
    elif entrada == 5:
        return dato_unico_cantidad_de_Inventario()
    elif entrada == 6:
        return consultar_categoria_precio()
    elif entrada == 7:
        return consultar_categoria_cantidad_de_inventario()
    else: 
        print("\tEntrada invalida\t\n"+
              "\tvuelve intentarlo")
        return 

"""
Método para consultar los datos unicos del ID.  
"""
def dato_unico_id():
    df = pd.read_csv("Inventario.csv")
    print(df['ID'].unique())

"""
Método para consultar los datos unicos por nombre.  
"""
def dato_unico_nombre():
    df = pd.read_csv("Inventario.csv")
    print(df['Nombre'].unique())

"""
Método para consultar los datos unicos por categoria.  
"""
def dato_unico_categoria():
    df = pd.read_csv("Inventario.csv")
    print(df['Categoria'].unique())

"""
Método para consultar los datos unicos de los precios.  
"""
def dato_unico_precio():
    df = pd.read_csv("Inventario.csv")
    print(df['Precio'].unique())

"""
Método para consultar los datos unicos del inventario.  
"""
def dato_unico_cantidad_de_Inventario():
    df = pd.read_csv("Inventario.csv")
    print(df['Cantidad_de_Inventario'].unique())

"""
Método para consultar los datos del inventario a tráves de la categoria y precio.  
"""
def consultar_categoria_precio():
    try: 
        Categoria = int(input("-------------------\n"
                              "Elige la categoria:\n"+
                              "-------------------\n"+
                              "1: Antibioticos\n"+
                              "2: Desinflamantes\n"+
                              "3: Analgésicos\n"+
                              "4: Alimentos\n"+
                              "5: Bebidas\n"+
                              "6: Otros\n"))
        Precio = int(input("Ingresa el precio: "))
    except ValueError:
        print("\t----------------------------------\n"+
              "\tLo siento pero eso no es un número\n"+
              "\t----------------------------------")
    menu_categorias(Categoria)
    df = pd.read_csv("Inventario.csv", index_col="ID")
    print(df[(df["Categoria"] == menu_categorias(Categoria)) & (df["Precio"] == Precio)])

"""
Método para consultar los datos del inventario a tráves de la categoria y cantidad de inventario.  
"""
def consultar_categoria_cantidad_de_inventario():
    try: 
        Categoria = int(input("-------------------\n"
                              "Elige la categoria:\n"+
                              "-------------------\n"+
                              "1: Antibioticos\n"+
                              "2: Desinflamantes\n"+
                              "3: Analgésicos\n"+
                              "4: Alimentos\n"+
                              "5: Bebidas\n"+
                              "6: Otros\n"))
        Cantidad_de_Inventario = int(input("Ingresa la Cantidad de Inventario: "))
    except ValueError:
        print("\t----------------------------------\n"+
              "\tLo siento pero eso no es un número\n"+
              "\t----------------------------------")
    menu_categorias(Categoria)
    df = pd.read_csv("Inventario.csv", index_col="ID")
    print(df[(df["Categoria"] == menu_categorias(Categoria)) & (df["Cantidad_de_Inventario"] == Cantidad_de_Inventario)])


"""
Método para consultar los datos unicos mediante columnas.  
"""
def datoUnicos(i):
    df = pd.read_csv("Inventario.csv", index_col="ID")
    print(df.iloc[:, i].unique())

"""
Método para elegir lo que quiere hacer nuestro usuario.
ya sea agregar,consultar...
@param entrada - el valor que nos proporciono el usuario.
@return el dato obtenido. 
"""
def principal(entrada):
    if entrada == 0:
        print("Saliste del programa :)")
        return 
    elif entrada == 1:
        return nuevo_dato_Unico()
    elif entrada == 2:
        return consultar_Dato()
    elif entrada == 3:
        return guarda_Ventas()
    else: 
        print("\tEntrada invalida\t\n"+
              "\tvuelve intentarlo")
        return 




"""
Método para guardar las ventas en un archivo csv.  
"""
def guarda_Ventas():
    print(get_all_data(filename))
    pregunta = input("¿Hay venta de algún producto?: escribe 'si' o 'no'\n").lower().strip()
    if(pregunta == "si"):
        pVendido = int(input("---------------------------------------\n"+
                         "¿Cuál es el ID del producto se vendio?:\n" 
                         "---------------------------------------\n"))
        quitar_existencias_de_producto(pVendido)
        #Aquí ver lo de la suma total 
        guarda_Ventas()
    elif(pregunta == "no"):
        print("------------------------------------------------------\n"+
              "Así quedo el csv del Inventario después de las ventas:\n"+
              "------------------------------------------------------\n")
        print(get_all_data(filename))
        print("-------------------------------\n"+
              "Así quedo el csv de las ventas:\n"+
              "-------------------------------\n")
        #Aquí iba a hacer otra forma pero ya no dió time :(.
        #dia = int(input("Dame el día:\n"))
        #mes = int(input("Dame el Mes:\n"))
        #year = int(input("Dame el año:\n"))

        """
        C = {'Dia': [dia],
             'Mes': [mes],
             'Año': [year],
             'TotalVentas': []}
        """

        
        C = {'Dia': ['05','06', '07'],
             'Mes': ['06', '06', '07'],
             'Año': ['2020', '2021', '2022'],
             'TotalVentas': ['5300', '2200', '3250'],
        }
        
        df = DataFrame(C, columns= ['Dia', 'Mes', 'Año', 'TotalVentas'])
        export_csv = df.to_csv (r'Ventas.csv', index = None, header=True) # here you have to write path, where result file will be stored
        #print (df)
        print(get_all_data2(filename2))
    else:
        print("Error: no pusiste si o no.")
        return 

"""
Método para quitar o reducir en -1 la cantidad de inventario de un producto.
@param id - el id del producto.
"""
def quitar_existencias_de_producto(id):
    df = pd.read_csv("Inventario.csv")
    auxVal = int(df.iat[id-1,4])
    Nombre = df.iat[id-1,1]
    if auxVal > 0:
        df.iat[id-1,4] = auxVal-1
        df.to_csv('Inventario.csv',index=False,header=True)
    else :
        print("Ya no se pueden quitar existencias, no hay " + Nombre + " en el inventario")    

#Aquí va hacer nuestro main. 
filename = 'Inventario.csv'
filename2 = 'Ventas.csv'
#Imprimimos los datos de nuestro csv.
print("------------------\n"+
      "Contenido del csv:\n"+
      "------------------\n")
print(get_all_data(filename))

try:
    teclado = int(input("--------------------------------------------------------\n"+
                        "Bienvenido al Menu elige una de las siguientes opciones:\n"+
                        "--------------------------------------------------------\n"+
                        "0: Salir del programa.\n"
                        "1: Agregar un nuevo producto al csv.\n"+
                        "2: Consultar un producto del csv.\n"+
                        "3: Almacenar ventas\n"))
except ValueError:
            print("\t----------------------------------\n"+
                "\tLo siento pero eso no es un número\n"+
                "\t----------------------------------")
principal(teclado)