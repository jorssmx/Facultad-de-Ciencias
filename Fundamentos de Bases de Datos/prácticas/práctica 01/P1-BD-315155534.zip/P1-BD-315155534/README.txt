Como compilar:
python3 Práctica_1.py


