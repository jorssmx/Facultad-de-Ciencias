[
    {
      "ID": 1,
      "Nombre": "Amoxicilina",
      "Categoria": "Antibioticos",
      "Precio": 150,
      "Cantidad_de_Inventario": 24
    },
    {
      "ID": 2,
      "Nombre": "Penincilina",
      "Categoria": "Antibioticos",
      "Precio": 250,
      "Cantidad_de_Inventario": 8
    },
    {
      "ID": 3,
      "Nombre": "Pepsi",
      "Categoria": "Bebidas",
      "Precio": 30,
      "Cantidad_de_Inventario": 12
    },
    {
      "ID": 4,
      "Nombre": "CocaCola",
      "Categoria": "Bebidas",
      "Precio": 40,
      "Cantidad_de_Inventario": 7
    },
    {
      "ID": 5,
      "Nombre": "Ibuprofeno",
      "Categoria": "Desinflamantes",
      "Precio": 180,
      "Cantidad_de_Inventario": 35
    },
    {
      "ID": 6,
      "Nombre": "Papas",
      "Categoria": "Alimentos",
      "Precio": 20,
      "Cantidad_de_Inventario": 9
    },
    {
      "ID": 7,
      "Nombre": "Metamizol",
      "Categoria": "Analgesicos",
      "Precio": 120,
      "Cantidad_de_Inventario": 22
    },
    {
      "ID": 8,
      "Nombre": "Cuaderno",
      "Categoria": "Otros",
      "Precio": 13,
      "Cantidad_de_Inventario": 4
    }
  ]